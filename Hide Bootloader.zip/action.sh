#!/system/bin/sh
U=https://evoker.qzz.io/key
echo 正在获取evoker密钥
PATH=/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
if command -v curl>/dev/null;then C="curl --connect-timeout 10 -Ls";else C="busybox wget -T 10 --no-check-certificate -qO-";fi
K=$($C $U|base64 -d)
[ -n "$K" ]||{ echo 下载失败;exit 1;}
echo 下载并解密成功
echo 正在替换密钥
for P in /data/adb/tricky_store/keybox.xml /data/adb/omk/omkdata/keybox.xml;do
[ -d "${P%/*}" ]||{ echo 未找到keybox.xml路径;continue;}
printf '%s\n' "$K">"$P"&&chmod 660 "$P"&&echo "替换成功 $P"
done