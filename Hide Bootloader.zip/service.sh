#!/system/bin/sh
D=${0%/*}
until dumpsys display|grep -q 'mScreenState=ON';do sleep 2;done
settings put global adb_enabled 0
TF=/data/adb/tricky_store/target.txt
IF=/data/adb/omk/omkdata/injector.toml
T=$IF.tmp
u(){
awk '
{ L[NR]=$0 }
END {
  buf="";inb=0
  for(i=1;i<=NR;i++){
    l=L[i]
    if(!inb){
      if(l~/^[ \t]*scoop[ \t]*=/){rest=l;if(!sub(/^[^[]*\[/,"",rest))continue;inb=1;buf=rest}else continue
    }else buf=buf" "l
    sub(/#.*/,"",buf)
    if(buf~/\]/)break
  }
  gsub(/[\[\]",]/," ",buf)
  n=split(buf,w,/[ \t]+/)
  for(i=1;i<=n;i++)if(w[i]!=""&&!(w[i] in s)){s[w[i]]=1;print w[i]}
}' "$IF" > "$T.e"
  cat "$T.e" > "$T.n"
  pm list packages -3 2>/dev/null|sed s/package://g|while read -r p;do [ -n "$p" ]&&(grep -Fxq "$p" "$T.n"||echo $p>>"$T.n";grep -Fxq "$p" "$TF"||echo $p>>"$TF");done
  { echo 'scoop = [';while read -r e;do echo "  $e";done<"$T.n";echo ']'; } > "$T.b"
  awk -v bf="$T.b" '
  BEGIN{while((getline l<bf)>0)B[++nb]=l;close(bf)}
  function emit(  k){for(k=1;k<=nb;k++)print B[k];ok=1}
  {
    if(!ok&&$0~/^[ \t]*scoop[ \t]*=/){emit();if($0!~/\]/)skip=1;next}
    if(skip){if($0~/\]/)skip=0;next}
    if(!ok&&$0~/^[ \t]*\[/)emit()
    print
  }
  END{if(!ok)emit()}' "$IF" > "$T"&&{ chmod 644 "$T" 2>/dev/null; mv -f "$T" "$IF"||cat "$T">"$IF"; }
  a=$(grep -c . "$TF" 2>/dev/null||echo 0);b=$(grep -c . "$T.n" 2>/dev/null||echo 0)
  rm -f "$T" "$T.e" "$T.n" "$T.b"
  grep -q 'target包名数量（[0-9]*个），injector包名数量（[0-9]*个）' "$D/module.prop" 2>/dev/null&&sed -i "s/target包名数量（[0-9]*个），injector包名数量（[0-9]*个）/target包名数量（$a个），injector包名数量（$b个）/" "$D/module.prop"||sed -i "s/^description=.*/&target包名数量（$a个），injector包名数量（$b个）/" "$D/module.prop"
}
u
inotifyd - /data/app/:m 2>/dev/null|while read -r e p;do u;done