#!/system/bin/sh
U=http://evoker.qzz.io/key
D=$(dirname "$(readlink -f "$0" 2>/dev/null||echo "$0")")
echo 正在获取Yuri密钥
PATH=/data/adb/magisk:/data/data/com.termux/files/usr/bin:$PATH
if command -v curl>/dev/null;then C="curl --connect-timeout 10 -Ls";else C="busybox wget -T 10 --no-check-certificate -qO-";fi
$C $U|base64 -d>"$D/keybox_decode"&&echo 下载并解密成功||{ echo 下载失败;exit 1;}
echo 正在替换密钥
mkdir -p /data/adb/tricky_store&&mv -f "$D/keybox_decode" /data/adb/tricky_store/keybox.xml&&echo 替换成功