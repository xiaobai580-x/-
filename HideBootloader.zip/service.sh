#!/system/bin/sh
D=${0%/*}
until dumpsys display|grep -q 'mScreenState=ON';do sleep 2;done
settings put global adb_enabled 0
setprop persist.sys.usb.config none
F=/data/adb/tricky_store/target.txt
u(){ pm list packages -3 2>/dev/null|sed s/package://g|while read -r p;do [ -n "$p" ]&&grep -Fxq "$p" $F||echo $p>>$F;done;n=$(grep -c . $F 2>/dev/null||echo 0);grep -q '目前包名数量\[[0-9]*\]个' "$D/module.prop" 2>/dev/null&&sed -i "s/目前包名数量\[[0-9]*\]个/目前包名数量[$n]个/" "$D/module.prop"||sed -i "s/^description=.*/&目前包名数量[$n]个/" "$D/module.prop";}
u
inotifyd - /data/app/:m 2>/dev/null|while read -r e p;do u;done