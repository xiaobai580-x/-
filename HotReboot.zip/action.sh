#!/system/bin/sh
echo "正在热重启……"
last_pid=$$
wrapped=0
while true; do
    : &
    p=$!
    [ "$p" -lt "$last_pid" ] && wrapped=1
    [ "$wrapped" -eq 1 ] && [ "$p" -ge 1700 ] && break
    last_pid=$p
done
setprop ctl.restart zygote
echo "热重启成功"