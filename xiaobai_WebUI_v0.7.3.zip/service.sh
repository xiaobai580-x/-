#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/xiaobai"
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
exec "$BIN" --daemon
