function matchpair(s, p, ob, cb,    d, i, c, n, instr, esc) {
    n = length(s); d = 0; instr = 0; esc = 0
    for (i = p; i <= n; i++) {
        c = substr(s, i, 1)
        if (instr) {
            if (esc) esc = 0
            else if (c == "\\") esc = 1
            else if (c == "\"") instr = 0
            continue
        }
        if (c == "\"") { instr = 1; continue }
        if (c == ob) d++
        else if (c == cb) { d--; if (d == 0) return i }
    }
    return 0
}
function valpos(s, kp,    p, i, n, c) {
    p = index(s, kp)
    if (p <= 0) return 0
    i = p + length(kp); n = length(s)
    while (i <= n) {
        c = substr(s, i, 1)
        if (c == ":") { i++; break }
        if (c == "}" || c == "]" || c == ",") return 0
        i++
    }
    while (i <= n) {
        c = substr(s, i, 1)
        if (c != " " && c != "\t" && c != "\n" && c != "\r") return i
        i++
    }
    return 0
}
function setbool(s, key, val,    vb) {
    vb = valpos(s, "\"" key "\"")
    if (vb <= 0) return s
    if (substr(s, vb, 4) == "true")  return substr(s, 1, vb - 1) val substr(s, vb + 4)
    if (substr(s, vb, 5) == "false") return substr(s, 1, vb - 1) val substr(s, vb + 5)
    return s
}
function normtop(S,    n, i, out, k, val) {
    n = split("configVersion detailLog errorOnlyLog maxLogSize forceMountData disableActivityLaunchProtection altAppDataIsolation altVoldAppDataIsolation skipSystemAppDataIsolation webViewProtection ignoreBrandProtections defaultConfig", OK, " ")
    out = "{"
    for (i = 1; i <= n; i++) {
        k = OK[i]
        if (k == "configVersion") val = "93"
        else if (k == "maxLogSize") val = "512"
        else if (k == "defaultConfig") val = "null"
        else if (k ~ /^(detailLog|errorOnlyLog|disableActivityLaunchProtection|altAppDataIsolation|altVoldAppDataIsolation|ignoreBrandProtections)$/) val = "false"
        else val = "true"
        if (i > 1) out = out ","
        out = out "\"" k "\":" val
    }
    return out "}"
}
function pkey(obj, i, n,    k) {
    k = i
    while (k <= n) {
        if (substr(obj, k, 2) == "\\\"") { k += 2; continue }
        if (substr(obj, k, 1) == "\"") break
        k++
    }
    return k
}
function elem(obj, i, n,    k, colon, vs, ve, c) {
    if (substr(obj, i, 1) != "\"") return 0
    k = pkey(obj, i + 1, n)
    if (k <= i) return 0
    colon = index(substr(obj, k), ":")
    if (colon <= 0) return 0
    vs = k + colon
    while (vs <= n) {
        c = substr(obj, vs, 1)
        if (c != " " && c != "\t" && c != "\n" && c != "\r") break
        vs++
    }
    c = substr(obj, vs, 1)
    if (c == "{") ve = matchpair(obj, vs, "{", "}")
    else if (c == "[") ve = matchpair(obj, vs, "[", "]")
    else {
        ve = vs
        while (ve <= n) {
            c = substr(obj, ve, 1)
            if (c == "," || c == "}") break
            ve++
        }
        ve--
    }
    if (ve < vs) return 0
    EK = substr(obj, i + 1, k - i - 1)
    EV = substr(obj, vs, ve - vs + 1)
    return ve
}
function rebuild(pref, n,    i, s) {
    s = "{"
    for (i = 1; i <= n; i++) {
        if (i > 1) s = s ","
        s = s "\"" A[pref, i, 1] "\":" A[pref, i, 2]
    }
    return s "}"
}
function idxof(pref, n, key,    i) {
    for (i = 1; i <= n; i++) if (A[pref, i, 1] == key) return i
    return 0
}
function parseinto(pref, obj,    n, j, len, e) {
    n = 0
    len = length(obj)
    j = 2
    while (j < len) {
        if (substr(obj, j, 1) != "\"") { j++; continue }
        e = elem(obj, j, len)
        if (e <= 0) break
        n++
        A[pref, n, 1] = EK
        A[pref, n, 2] = EV
        j = e + 1
        while (j < len && substr(obj, j, 1) == ",") j++
    }
    return n
}
function scope_default() {
    return "{\"useWhitelist\":false,\"excludeSystemApps\":true,\"hideInstallationSource\":false," \
           "\"hideSystemInstallationSource\":false,\"excludeTargetInstallationSource\":false," \
           "\"invertActivityLaunchProtection\":false,\"excludeVoldIsolation\":false," \
           "\"restrictedZygotePermissions\":[],\"applyTemplates\":[\"" tpl "\"]," \
           "\"applyPresets\":[],\"applySettingTemplates\":[],\"applySettingsPresets\":[]," \
           "\"extraAppList\":[],\"extraOppositeAppList\":[]}"
}
function scope_fix(v,    n, k, i) {
    if (substr(v, 1, 1) != "{") return scope_default()
    n = parseinto("S1", v)

    split("useWhitelist excludeSystemApps hideInstallationSource hideSystemInstallationSource excludeTargetInstallationSource invertActivityLaunchProtection excludeVoldIsolation restrictedZygotePermissions applyTemplates applyPresets applySettingTemplates applySettingsPresets extraAppList extraOppositeAppList", DK, " ")

    for (i = 1; i <= 14; i++) {
        if (DK[i] == "applyTemplates") tval = "[\"" tpl "\"]"
        else if (DK[i] == "excludeSystemApps") tval = "true"
        else if (DK[i] ~ /^(restrictedZygotePermissions|applyPresets|applySettingTemplates|applySettingsPresets|extraAppList|extraOppositeAppList)$/) tval = "[]"
        else tval = "false"
        k = idxof("S1", n, DK[i])
        if (k > 0) A["S1", k, 2] = tval
        else { n++; A["S1", n, 1] = DK[i]; A["S1", n, 2] = tval }
    }

    return rebuild("S1", n)
}
function defaultcfg(    s) {
    s = "{\"configVersion\":93,\"detailLog\":false,\"errorOnlyLog\":false,\"maxLogSize\":512,"
    s = s "\"forceMountData\":true,\"disableActivityLaunchProtection\":false,"
    s = s "\"altAppDataIsolation\":false,\"altVoldAppDataIsolation\":false,"
    s = s "\"skipSystemAppDataIsolation\":true,\"webViewProtection\":true,"
    s = s "\"ignoreBrandProtections\":false,\"defaultConfig\":null,"
    s = s "\"ignoredPackagesForPresets\":[],\"templates\":{},\"settingsTemplates\":{},"
    s = s "\"disabledHooks\":[],\"scope\":{}}"
    return s
}
function trim(s) {
    gsub(/^[ \t]+/, "", s)
    gsub(/[ \t]+$/, "", s)
    return s
}
BEGIN {
    invn = 0
    actn = 0
    sec = 0
    while ((getline line < listf) > 0) {
        gsub(/\r/, "", line)
        line = trim(line)
        if (line == "") continue
        if (substr(line, 1, 1) == "#") {
            if (index(line, "=====") > 0) {
                if (index(line, "不可见应用") > 0) sec = 1
                else if (index(line, "生效应用") > 0) sec = 2
            }
            continue
        }
        if (sec == 0) { invn++; INV[invn] = line; continue }
        if (sec == 1) { invn++; INV[invn] = line }
        else if (sec == 2) { actn++; ACT[actn] = line }
    }
    close(listf)
    if (invn == 0 && actn == 0) {
        print "ERR 名单文件里没有任何包名（不可见与生效都为空）：" listf > "/dev/stderr"
        exit 3
    }

    S = ""
    if (mode == "merge") {
        while ((getline line < cfgf) > 0) {
            if (++lnr == 1) sub(/^\357\273\277/, "", line)
            S = S line
        }
        close(cfgf)
    }
    if (S == "") S = defaultcfg()

    nk = split("detailLog errorOnlyLog disableActivityLaunchProtection altAppDataIsolation altVoldAppDataIsolation ignoreBrandProtections", BK, " ")
    for (i = 1; i <= nk; i++) S = setbool(S, BK[i], "false")

    nk = split("forceMountData skipSystemAppDataIsolation webViewProtection", BK2, " ")
    for (i = 1; i <= nk; i++) S = setbool(S, BK2[i], "true")

    tp0 = valpos(S, "\"templates\"")
    if (tp0 <= 0) { print "ERR 配置缺少 templates 键" > "/dev/stderr"; exit 4 }
    key0 = index(substr(S, 1, tp0 - 1), "\"ignoredPackagesForPresets\"")
    tail0 = ""
    if (key0 > 0) {
        tail0 = substr(S, key0)
    } else {
        comma0 = 0
        for (i = tp0 - 1; i > 0; i--) {
            if (substr(S, i, 1) == ",") { comma0 = i; break }
        }
        if (comma0 <= 0) { print "ERR 配置结构异常，找不到顶层分隔" > "/dev/stderr"; exit 5 }
        tail0 = "\"ignoredPackagesForPresets\":[]," substr(S, tp0)
    }
    head0 = normtop(S)
    S = substr(head0, 1, length(head0) - 1) "," tail0

    apparr = "["
    if (invn > 0) {
        for (i = 1; i <= invn; i++) {
            if (i > 1) apparr = apparr ","
            apparr = apparr "\"" INV[i] "\""
        }
    }
    apparr = apparr "]"

    tp = valpos(S, "\"templates\"")
    if (tp <= 0) { print "ERR 配置缺少 templates 键" > "/dev/stderr"; exit 4 }
    te = matchpair(S, tp, "{", "}")
    if (te <= tp) { print "ERR templates 结构不完整" > "/dev/stderr"; exit 5 }

    tobj = substr(S, tp, te - tp + 1)
    tn = parseinto("T", tobj)
    k = idxof("T", tn, tpl)

    if (k <= 0) {
        for (i = 1; i <= tn; i++) {
            if (A["T", i, 2] ~ /"isWhitelist":[ \t]*false/) {
                k = i
                tpl = A["T", i, 1]
                break
            }
        }
    }
    if (k > 0) tpl_used = A["T", k, 1]
    else tpl_used = tpl
    if (invn > 0) {
        newtpl = "{\"isWhitelist\":false,\"appList\":" apparr "}"
        if (k > 0) A["T", k, 2] = newtpl
        else { tn++; A["T", tn, 1] = tpl; A["T", tn, 2] = newtpl }
        S = substr(S, 1, tp - 1) rebuild("T", tn) substr(S, te + 1)
    } else {
        print "WARN 不可见应用为空，模板 appList 保持原样" > "/dev/stderr"
    }

    if (actn > 0) {
        tp = valpos(S, "\"templates\"")
        if (tp > 0) {
            te = matchpair(S, tp, "{", "}")
            if (te > tp) {
                tn = parseinto("T", substr(S, tp, te - tp + 1))
                changed = 0
                for (i = 1; i <= tn; i++) {
                    if (A["T", i, 1] == tpl_used) continue
                    v = A["T", i, 2]
                    ap = valpos(v, "\"appList\"")
                    if (ap <= 0) continue
                    ae = matchpair(v, ap, "[", "]")
                    if (ae <= ap) continue
                    m = split(substr(v, ap + 1, ae - ap - 1), Q, ",")
                    out = ""
                    for (j = 1; j <= m; j++) {
                        q = trim(Q[j])
                        if (q == "") continue
                        qq = q
                        gsub(/^"|"$/, "", qq)
                        skip = 0
                        for (z = 1; z <= actn; z++) if (qq == ACT[z]) { skip = 1; break }
                        if (skip) continue
                        if (out != "") out = out ","
                        out = out q
                    }
                    newv = substr(v, 1, ap - 1) "[" out "]" substr(v, ae + 1)
                    if (newv != v) { A["T", i, 2] = newv; changed = 1 }
                }
                if (changed) S = substr(S, 1, tp - 1) rebuild("T", tn) substr(S, te + 1)
            }
        }
    }


    sp = valpos(S, "\"scope\"")
    if (sp <= 0) { print "ERR 配置缺少 scope 键" > "/dev/stderr"; exit 6 }
    se = matchpair(S, sp, "{", "}")
    if (se <= sp) { print "ERR scope 结构不完整" > "/dev/stderr"; exit 7 }

    sobj = substr(S, sp, se - sp + 1)
    sn = parseinto("U", sobj)
    if (actn > 0) {
        for (i = 1; i <= actn; i++) {
            k = idxof("U", sn, ACT[i])
            if (k > 0) A["U", k, 2] = scope_fix(A["U", k, 2])
            else {
                sn++
                A["U", sn, 1] = ACT[i]
                A["U", sn, 2] = scope_default()
            }
        }
        S = substr(S, 1, sp - 1) rebuild("U", sn) substr(S, se + 1)
    } else {
        print "WARN 生效应用为空，scope 保持原样" > "/dev/stderr"
    }

    printf "%s", S
    exit 0
}
