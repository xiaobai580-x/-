#!/system/bin/sh
set_perm "$MODPATH/xiaobai" 0 0 0777
set_perm "$MODPATH/hma.awk" 0 0 0777
set_perm "$MODPATH/service.sh" 0 0 0777