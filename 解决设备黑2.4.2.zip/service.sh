#!/system/bin/sh
f="${0%/*}/小白配置.prop" p=/data/vendor/mediadrm
rmmod inte 2>/dev/null
while :;do
b=""
[ -f "$f" ]&&while IFS= read -r l||[ -n "$l" ];do case $l in ""|"#"*)continue;;esac;b="$b $l";done<$f
r=1
for d in $b;do pidof $d >/dev/null 2>&1&&{ r=0;break; };done
for d in $b;do pidof $d >/dev/null 2>&1&&continue;for u in /data/user/*;do [ -e "$u/$d/files/ano_tmp" ]&&rm -rf "$u/$d/files/ano_tmp" 2>/dev/null;for n in cache code_cache;do [ -e "$u/$d/$n" ]&&rm -rf "$u/$d/$n" 2>/dev/null;done;done;done
if [ $r = 0 ];then
[ -d $p ]&&[ "$(stat -c %a $p 2>/dev/null)" != 000 ]&&chmod 000 $p 2>/dev/null
else
[ "$(stat -c %a $p 2>/dev/null)" = 770 ]&&{ sleep $(dumpsys display|grep -q mScreenState=OFF&&echo 5||echo 1);continue; }
[ -d $p ]&&chmod 770 $p 2>/dev/null
stop drm;stop mediadrm;stop clearkey;stop vendor.drm-widevine-hal-1-4;stop vendor.drm-clearkey-hal-1-4
for s in android.hardware.drm@1.0-service.widevine android.hardware.drm@1.1-service.widevine android.hardware.drm@1.2-service.widevine android.hardware.drm@1.3-service.widevine android.hardware.drm@1.4-service.widevine android.hardware.drm-service.widevine android.hardware.drm@1.4-service.clearkey android.hardware.drm-service.clearkey;do killall $s 2>/dev/null;done
pkill -f widevine 2>/dev/null
fi
sleep $(dumpsys display|grep -q mScreenState=OFF&&echo 5||echo 2)
done